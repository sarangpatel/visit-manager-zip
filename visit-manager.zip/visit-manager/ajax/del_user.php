<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
//update, else insert
if(!empty($user_id) && $user_id != 0){
	if(db_delete($user_id)){
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}else{
	echo json_encode(array('error' => true, 'msg' => 'error'));
}
?>