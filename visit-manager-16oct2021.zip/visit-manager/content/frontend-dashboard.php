
					<div class="row top-buttons ">
						<div class="col-md-12">
							<a href="?page=frontend-create-plan" class="btn  btn-sm btn-primary" >Create Visit Plan</a> &nbsp; &nbsp;
							<a href="?page=frontend-create-report" class="btn  btn-sm btn-primary " >Create New Report</a>
						</div>
					</div>
					<ul class="nav nav-tabs" id="myTab" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="email-tab" data-bs-toggle="tab" href="#upcoming-visit" role="tab" aria-controls="upcoming-visit" aria-selected="true">Upcoming Visits</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="appearance-tab" data-bs-toggle="tab" href="#submitted-report" role="tab" aria-controls="submitted-report" aria-selected="false">Submitted Reports</a>
						</li>
					</ul>
					<div class="tab-content" id="myTabContent">
						<div class="tab-pane fade active show" id="upcoming-visit" role="tabpanel" aria-labelledby="upcoming-tab">
							<h2>Your upcoming visits</h2><hr />
							<div class = "mb-2 plan-list">
								<div class = "col-md-12">DATE / TIME </div>
								<div class = "col-md-12">Customer - Location / Estate </div>
								<div class = "col-md-12">Activty ( Product ) </div>
								<div class = "col-md-12"><button class = "btn btn-sm btn-primary">Detail</button></div>
							</div>
							<hr />
							<div class = "row mb-2 plan-list" >
								<div class = "col-md-12">DATE / TIME </div>
								<div class = "col-md-12">Customer - Location / Estate </div>
								<div class = "col-md-12">Activty ( Product ) </div>
							</div>
							<hr />

							<div class = "row  mb-2 plan-list">
								<div class = "col-md-12">DATE / TIME </div>
								<div class = "col-md-12">Customer - Location / Estate </div>
								<div class = "col-md-12">Activty ( Product ) </div>
							</div>

							<!--<div class="col-md-12">
								<p class="text-muted">Email SMTP settings, notifications and others related to email.</p>
								<div class="mb-3">
									<label for="" class="form-label">Protocol</label>
									<select name="" class="form-select">
										<option value="">Select Protocol</option>
										<option value="">SMTP</option>
										<option value="">Sendmail</option>
										<option value="">PHP Mailer</option>
									</select>
								</div>
								<div class="mb-3">
									<label for="" class="form-label">SMTP Host</label>
									<input type="text" name="" class="form-control">
								</div>
								<div class="mb-3">
									<label for="" class="form-label">SMTP Username</label>
									<input type="text" name="" class="form-control">
								</div>
								<div class="mb-3">
									<label for="" class="form-label">SMTP Security</label>
									<select name="" class="form-select">
										<option value="">Select SMTP Security</option>
										<option value="">TLS</option>
										<option value="">SSL</option>
										<option value="">None</option>
									</select>
								</div>
								<div class="mb-3">
									<label for="" class="form-label">SMTP Port</label>
									<input type="text" name="" class="form-control">
								</div>
								<div class="mb-3">
									<label for="" class="form-label">SMTP Password</label>
									<input type="password" name="" class="form-control">
								</div>
								<div class="mb-3 ">
									<button class="btn  btn-primary" type="submit">Submit</button>
								</div>
							</div>-->
						</div>
						<div class="tab-pane fade" id="submitted-report" role="tabpanel" aria-labelledby="submitted-report">
							<div class="col-md-6">
								<p class="text-muted">Application settings, language, time zones and other environments.</p>
								<div class="mb-3">
									<label for="language" class="form-label">Default Language</label>
									<select class="form-select" name="language">
										<option value="en">English</option>
										<option value="es">Spanish</option>
										<option value="fr">French</option>
									</select>
								</div>
							</div>
						</div>
					</div>
