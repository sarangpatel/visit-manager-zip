<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';


## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = trim($_POST['search']['value']); // Search value
$searchQuery = '';
if($searchValue != ''){
   $searchQuery .= "  and ( country_name like '%".$searchValue."%' or  
		 created_on like '%".$searchValue."%' ) ";
}

## Total number of records without filtering
#$sel = mysqli_query($con,"select count(*) as allcount from employee");
#$records = mysqli_fetch_assoc($sel);
#$totalRecords = $records['allcount'];

$query = "select count(1) as allcount from countries WHERE is_deleted = 0" ;
$stmt = $conn->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$totalRecords = $records[0]['allcount'];



## Total number of records with filtering
#$sel = mysqli_query($con,"select count(1) as allcount from employee WHERE 1 ".$searchQuery);
#$records = mysqli_fetch_assoc($sel);
#$totalRecordwithFilter = $records['allcount'];

$query = "select * from countries WHERE is_deleted = 0 ".$searchQuery ;
$stmt = $conn->prepare($query);
$stmt->execute();
$num = $stmt->rowCount();
$totalRecordwithFilter = $num;


## Fetch records
#$empQuery = "select * from employee WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
#$empRecords = mysqli_query($con, $empQuery);

$query = "select * from countries WHERE  is_deleted = 0 ".$searchQuery ." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$stmt = $conn->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$data = array();
foreach($records as $row){
   $data[] = array(
     "country_name"=>$row['country_name'],
     "is_active"=>$row['is_active']? 'Active': 'Inactive',
     "created_on" => $row['created_on'],
    'action' => getActionLinks($row)
   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);
echo json_encode($response);

function getActionLinks($row){
	$editAttr = " data-countryid = {$row['id']} data-name = '{$row['country_name']}'  " .
				" data-isactive = '{$row['is_active']}' " ;
	
	$editLink = "<a href=\"#\" class=\"btn btn-outline-info btn-rounded editLink \"  $editAttr ><i class=\"fas fa-pen\"></i></a>";

	$delAttr = " data-countryid = {$row['id']} " ; 
	$delLink = "<a href=\"#\" class=\"btn btn-outline-danger btn-rounded delLink\" $delAttr ><i class=\"fas fa-trash\"></i></a>";

	return $editLink . ' ' . $delLink;
}

exit;


?>