<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);


if(!empty($_POST["keyword"])){
	$query ="SELECT * FROM customers WHERE customer_name like '" . $_POST["keyword"] . "%' ORDER BY customer_name LIMIT 0,300";
	$data  = select_query($query);
	if(!empty($data)){ ?>
		<ul id="country-list">
		<?php foreach($data as $c) { ?>
		<li class = "listitem" onClick="selectCountry('<?php echo $c["id"]; ?>', '<?php echo $c["customer_name"]; ?>' );"><?php echo $c["customer_name"]; ?></li>
		<?php } ?>
		</ul>
	<?php }else{ ?>
		<ul id="country-list">
			<li class = "listitem" >No record found</li>
		</ul>
	 <?php } ?>
<?php } ?>

