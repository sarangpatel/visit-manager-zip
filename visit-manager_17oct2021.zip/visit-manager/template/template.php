<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php page_title(); ?> | <?php site_name(); ?></title>
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/datatables/datatables.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/css/master.css" rel="stylesheet">
</head>

<body>
	<script>var SITE_URL = '<?php echo site_url(); ?>/';</script>
    <div class="wrapper">
        <!-- sidebar navigation component -->
        <nav id="sidebar" ><!-- class="active" //default hide sidebar -->
            <div class="sidebar-header">
                <img src="<?php site_url(); ?>/template/assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo">
            </div>
            <ul class="list-unstyled components text-secondary">
                <li class = "<?php echo (empty($_GET['page']) || ( $_GET['page']  =='home' || $_GET['page'] == '')) ? 'active': ''  ; ?>"  >
                    <a href="?page=home"><i class="fas fa-user-friends"></i>Users</a>
                </li>
                <li class="<?php echo ($_GET['page']  =='products') ? 'active': ''  ; ?>">
                    <a href="?page=products"><i class="fas fa-layer-group"></i>Products</a>
                </li>
                <li class="<?php echo ($_GET['page']  =='countries') ? 'active': ''  ; ?>">
                    <a href="?page=countries"><i class="fas fa-flag"></i>Countries</a>
                </li>

            </ul>
        </nav>
        <!-- end of sidebar component -->
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <nav class="navbar navbar-expand-lg navbar-white bg-white">
                <button type="button" id="sidebarCollapse" class="btn btn-light">
                    <i class="fas fa-bars"></i><span></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav1" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-link"></i> <span>Quick Links</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu" aria-labelledby="nav1">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-list"></i> Access Logs</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-database"></i> Back ups</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cloud-download-alt"></i> Updates</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-user-shield"></i> Roles</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav2" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user"></i> <span>John Doe</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-address-card"></i> Profile</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-envelope"></i> Messages</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cog"></i> Settings</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- end of navbar navigation -->
			<?php page_content(); ?>
        </div><!-- body -->
    </div>
	<div class ="footer">
		<small>&copy;<?php echo date('Y'); ?> <?php site_name(); ?></small>
	</div>

    <script src="<?php site_url(); ?>/template/assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php site_url(); ?>/template/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php site_url(); ?>/template/assets/vendor/datatables/datatables.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
	<script src="<?php site_url(); ?>/template/assets/js/custom_cookie.js"></script>
    <script src="<?php site_url(); ?>/template/assets/js/script.js"></script>
</body>
</html>