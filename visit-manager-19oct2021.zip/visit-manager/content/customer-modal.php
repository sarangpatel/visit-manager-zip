<style>
    .autocomplete-suggestions { border: 1px solid #999; background: #FFF; overflow: auto; }
	.autocomplete-suggestion { padding: 2px 5px; white-space: nowrap; overflow: hidden; }
	.autocomplete-selected { background: #F0F0F0; }
	.autocomplete-suggestions strong { font-weight: normal; color: #3399FF; }
	.autocomplete-group { padding: 2px 5px; }
	.autocomplete-group strong { display: block; border-bottom: 1px solid #000; }
  </style>

		   <div class="modal fade" id="customerAddModal" role="dialog" tabindex="-1">
			  <div class="modal-dialog">
				<div class="modal-content">
				<form accept-charset="utf-8" name = "addcustomer_frm" >
					  <input type ="hidden" name = "customer_id" value = "0">
					  <div class="modal-header">
						<h5 class="modal-title">Add Customer</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					  </div>
					  <div class="modal-body text-start">
							<div class="mb-3">
								<label class="form-label">Customre Name<span class= "mandatory">*</span></label>
								<input type="text" name="customer_name"  id="autocomplete" class="form-control" autocomplete = "off" >
							</div>
							<div class="mb-3">
								<label class="form-label">Location / Estate<span class= "mandatory">*</span></label>
								<input type="text" name="location_estate" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Contact Person<span class= "mandatory">*</span></label>
								<input type="text" name="contact_person" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Phone Number<span class= "mandatory">*</span></label>
								<input type="text" name="mobile" class="form-control">
								<small class="form-text text-muted">For Ex:  +658454049404</small>
							</div>
					  </div>
					  <div class="modal-footer">
						<button type="submit" class="btn btn-primary" >Submit</button>
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					  </div>
				</form>
				</div>
			  </div>
			</div>
