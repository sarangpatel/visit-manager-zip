<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
//update, else insert
if(!empty($product_id) && $product_id != 0){

	$dt = date('Y-m-d H:i:s');
	$user = current_logged_user();
	$user_id = $user['id'];
	$query = "update products set is_deleted = 1, updated_on = '$dt', updated_by= $user_id where id = $product_id" ;
	if(delete_query($query)){
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}else{
	echo json_encode(array('error' => true, 'msg' => 'error'));
}
?>