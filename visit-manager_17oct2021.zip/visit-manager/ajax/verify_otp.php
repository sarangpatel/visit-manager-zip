<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);

$data = array('otp' => $otp,'via_id' => $email_mobile);
$now  = date('Y-m-d H:i:s');
$query = "select via_id, via from otps where via_id = :via_id and otp = :otp and expired_on >= '$now' order by id desc limit 1" ;
$data = select_query($query,$data);
if(count($data) > 0 ){
	if($data[0]['via'] == 'email'){
		$query = "select name,country_id,id from users where email = :via_id AND is_deleted = 0 AND is_active = 1 " ;
		$data = select_query($query,array('via_id' => $data[0]['via_id']));
		if(count($data) > 0 ){
			log_activity(array('created_by' =>  $data[0]['id'],  'country_id' =>  $data[0]['country_id'] , 'action_type' => 'info', 'description' =>   $data[0]['name'] . '(#' .  $data[0]['id'] . ') Logged in at ' . date('Y-m-d H:i:s') ));
			echo json_encode(array('error' => false, 'msg' => 'success', 'data' => array('user_id' => $data[0]['id'])));
		}else{
			echo json_encode(array('error' => true, 'msg' => 'User not exists.'));
		}
	}
}else{
	echo json_encode(array('error' => true, 'msg' => 'OTP is not valid or its been expired.'));
}

?>