<?php
session_start();
date_default_timezone_set('UTC');
error_reporting(E_ALL);
ini_set('display_errors', 1); //0 to hide display error
/**
 * Used to store website configuration information.
 *
 * @var string or null
 */
function config($key = '')
{
    $config = [
        'name' => 'Visit Manager',
        'site_url' => '/visit-manager',
        'pretty_uri' => false,
		'database' => [
			'host' => 'localhost',
			'username' => 'root',
			'password' => '',
			'dbname' => 'visit_manager'
		],
        'template_path' => 'template',
        'content_path' => 'content',
        'version' => 'v3.1',
		'account_types' => ['manager' => 'Manager', 'field_team_member' => 'Field Team Member']
    ];

    return isset($config[$key]) ? $config[$key] : null;
}
