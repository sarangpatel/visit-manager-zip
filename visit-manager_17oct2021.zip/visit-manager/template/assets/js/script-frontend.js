/*------------------------------------------------------------------
* Bootstrap Simple Admin Template
* Version: 3.0
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-------------------------------------------------------------------*/

$(function() {
	$.validator.addMethod("nameChars", function(value, element) {
	  return this.optional(element) || /^[a-z0-9\-\s]+$/i.test(value);
	}, "Field must contain only letter, numbers or dashes");
});

	/*** STAR CREATE PLAN ***/

	$("form[name='addplan_frm']").validate({
		// Specify validation rules
		rules: {
			plan_datetime: {
				required: true
			},
			activity_type: {
				required: true
			},
			customer_id: {
				required: true
			},
			product_id: {
				required: true
			},

		},
		submitHandler: function(form) {
			console.log('form add plan');
			let msg = parseInt($("form[name='addplan_frm']").find("input[name='plan_id']").val()) === 0 ? 'added' : 'updated'; 
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			$.ajax({
					url : SITE_URL + 'ajax/add_plan.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					setTimeout(() => window.location.href = '?page=frontend-dashboard', 500);
					swal('Success!', 'Plan ' + msg + ' successfully.', "success");
				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );

			});
			return false;
		}
	});
	/**************** END CREATE PLAN **************************/

	
	/*** STAR CREATE REPORT  ***/

	$("form[name='addreport_frm']").validate({
		rules: {
			plan_datetime: {
				required: true
			},
			activity_type: {
				required: true
			},
			customer_id: {
				required: true
			},
			product_id: {
				required: true
			},
			result: {
				required: true,
				maxlength: 500
			},
			next_steps: {
				required: true,
				maxlength: 500
			}
		},
		submitHandler: function(form) {
			console.log('form add report');
			let msg = parseInt($("form[name='addreport_frm']").find("input[name='report_id']").val()) === 0 ? 'added' : 'updated'; 
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			$.ajax({
					url : SITE_URL + 'ajax/add_report.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					setTimeout(() => window.location.href = '?page=frontend-dashboard', 500);
					swal('Success!', 'Report ' + msg + ' successfully.', "success");
				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );

			});
			return false;
		}
	});
	/**************** END CREATE REPORT **************************/

	/*** STAR CREATE CUSTOMER  ***/

	$("form[name='addcustomer_frm']").validate({
		rules: {
			customer_name: {
				required: true,
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			location_estate: {
				required: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			contact_person: {
				required: true,
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			mobile: {
				required: true,
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function(form) {
			console.log('form add customer');
			let msg = parseInt($("form[name='addcustomer_frm']").find("input[name='customer_id']").val()) === 0 ? 'added' : 'updated'; 
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			$.ajax({
					url : SITE_URL + 'ajax/add_customer.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					//setTimeout(() => window.location.href = '?page=frontend-dashboard', 500);
					swal('Success!', 'Customer ' + msg + ' successfully.', "success");
					if($("form[name='addplan_frm']").length)
					$("form[name='addplan_frm']").find("select[name='customer_id']").append('<option value="' +  data.data.customer_id + '" selected="selected">' + data.data.customer_name + ' </option>');

					if($("form[name='addreport_frm']").length)
					$("form[name='addreport_frm']").find("select[name='customer_id']").append('<option value="' +  data.data.customer_id + '" selected="selected">' + data.data.customer_name + ' </option>');


					$('#customerAddModal').modal('hide');
				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );

			});
			return false;
		}
	});
	/**************** END CREATE CUSTOMER **************************/


	$('#customerAddModal').on('hide.bs.modal', function (){
		$("form[name='addcustomer_frm']").find("input[name='customer_id']").val(0);
		$("form[name='addcustomer_frm']").validate().resetForm();
		$("form[name='addcustomer_frm']")[0].reset();
		
	});


 /**** country autocomplete **/
	$("form[name='addcustomer_frm']").find('input[name="customer_name"]').keyup(function(){
		$.ajax({
		type: "POST",
		url:  SITE_URL + 'ajax/customer_list.php',
		data: {keyword: $(this).val()},
		beforeSend: function(){
			$(this).css("background","#FFF url('"  +  SITE_URL +  "/template/assets/img/LoaderIcon.gif" + "') no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});

	$("form[name='addcustomer_frm']").find('input[name="customer_name"]').blur(function(){
		$("#suggesstion-box").hide();
		$("form[name='addcustomer_frm']").find('input[name="customer_id"]').val(0);

	});

function selectCountry(id,name){
	$("form[name='addcustomer_frm']").find('input[name="customer_name"]').val(name);
	$("form[name='addcustomer_frm']").find('input[name="customer_id"]').val(id);
	$("#suggesstion-box").hide();
}

$( "ul#country-list li" ).keyup(function() {
	console.log($(this).html());
})
	

 /** country autocomplete **/

	$('.plan-list').click(function(v){
		let plan_id = $(this).data('id');
		window.location.href = '?plan_id=' + plan_id + '&page=frontend-create-plan';
	});

	$('.report-list').click(function(v){
		let report_id = $(this).data('id');
		window.location.href = '?report_id=' + report_id + '&page=frontend-create-report';
	});
	
	$('#myTabContent').on('click', '.planDel', function (evt) {
			evt.preventDefault();
			let plan_id = $(this).data('planid');
			swal({
				title: "Are you sure ??",
				text: "", 
				icon: "warning",
				buttons: true,
				dangerMode: true
			})
			 .then((willDelete) => {
				  if (willDelete) {
					$.ajax({
							url : SITE_URL + 'ajax/del_plan.php',
							type: 'POST',
							dataType: 'json',
							data: {plan_id: plan_id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "Plan deleted successfully.", "success");
						setTimeout(() => window.location.reload(),1200);
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
				  } else {
					//swal("Your imaginary file is safe!");
				  }
			});
			return false;
	});



	if($("form[name='addplan_frm']").length){
		//let regex = new RegExp('[?&]' + 'plan_id' + '(=([^&#]*)|&|#|$)');
		//let results = regex.exec(window.location.href);
		//let plan_id = decodeURIComponent(results[2].replace(/\+/g, ' '));
		//$("form[name='addplan_frm']").find("input[name='plan_id']").val(plan_id);
		$("form[name='addplan_frm']").find('input[name="plan_datetime"]').datetimepicker({'format': 'Y-m-d H:i:s', 'minDate': Date.now(),'step':20});
	}

	if($("form[name='addreport_frm']").length){
		//let regex = new RegExp('[?&]' + 'plan_id' + '(=([^&#]*)|&|#|$)');
		//let results = regex.exec(window.location.href);
		//let plan_id = decodeURIComponent(results[2].replace(/\+/g, ' '));
		//$("form[name='addplan_frm']").find("input[name='plan_id']").val(plan_id);
		$("form[name='addreport_frm']").find('input[name="plan_datetime"]').datetimepicker({'format': 'Y-m-d H:i:s', 'minDate': Date.now(),'step':20});
	}

