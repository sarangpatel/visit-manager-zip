<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
if(!empty($customer_name)){
	$customer = customer_name_exists($customer_name);
	if(!$customer){
		echo "true";
	}else{
		echo "false";
	}
}
exit;
?>