<?php
session_unset($_SESSION['user']);
session_destroy();
setcookie("logged_user_id", "", time() - 3600, "/");
setcookie("logged_in", "", time() - 3600, "/");
header('Location: ?page=login');
exit;
?>