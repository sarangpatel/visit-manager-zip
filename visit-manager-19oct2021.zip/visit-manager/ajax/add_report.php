<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);


$dt = date('Y-m-d H:i:s');
$user_id = current_logged_user();
$country_id = $_SESSION['user']['country_id'];
//$result = nl2br($result);
//$next_steps = nl2br($next_steps);

if(!empty($report_id) && $report_id != 0){
	$data = array('plan_id' => $plan_id, 'plan_datetime' => $plan_datetime,'country_id' => $country_id, 'customer_id' => $customer_id, 'product_id' => $product_id, 
				'activity_type' => $activity_type, 'result' => $result, 'next_steps' => $next_steps,  'user_id' => $user_id['id']);
	$query = "update visit_reports set plan_id = :plan_id, plan_datetime = :plan_datetime, country_id = :country_id, customer_id = :customer_id, product_id = :product_id,
				activity_type = :activity_type, result = :result, next_steps = :next_steps, user_id= :user_id where id = $report_id" ;
	if(update_query($query,$data)){
		log_activity(array('action_type' => 'update', 'description' =>  'Visit Report has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}else{
	$data = array('plan_id' => $plan_id, 'plan_datetime' => $plan_datetime,'country_id' => $country_id, 'customer_id' => $customer_id, 'product_id' => $product_id, 
				'activity_type' => $activity_type, 'result' => $result, 'next_steps' => $next_steps,'created_on' => $dt,'user_id' => $user_id['id']);
	$query = "insert into visit_reports (plan_id,plan_datetime, country_id, customer_id,product_id,activity_type,result,next_steps,created_on,user_id) values 
			(:plan_id, :plan_datetime, :country_id, :customer_id,:product_id,:activity_type,:result,:next_steps, :created_on, :user_id)" ;
	if(insert_query($query,$data)){
		if(!empty($plan_id)){
			update_query("UPDATE visit_plans SET is_report_submitted = :report_submit where id = $plan_id", array('report_submit' => 1));
		}
		log_activity(array('action_type' => 'add', 'description' =>  'Visit Report has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>