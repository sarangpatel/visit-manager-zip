<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);

$dt = date('Y-m-d H:i:s');
$otp = generateNumericOTP(6);
$data = array('otp' => $otp,'via' => 'email', 'created_on' => date('Y-m-d H:i:s'), 'expired_on' => date('Y-m-d H:i:s', strtotime('+1 hour')), 'via_id' => $email_mobile);
$query = "insert into otps (otp, via, created_on,  expired_on, via_id) values (:otp, :via, :created_on, :expired_on, :via_id)" ;

if(email_mobile_exists($email_mobile)){
	if(insert_query($query,$data)){
		 echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		 echo json_encode(array('error' => true, 'msg' => 'Error in OTP insertion.'));
	}
}else{
	echo json_encode(array('error' => true, 'msg' => 'Email not exists. Please try other.'));
}

?>