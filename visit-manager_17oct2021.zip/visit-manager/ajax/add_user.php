<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
//update, else insert
$data = array('name' => $name,'mobile' => $mobile, 'is_active' => $is_active , 'email' => $email,'country_id' => $country_id, 'account_type' => $account_type);
if(!empty($user_id) && $user_id != 0){
	if(db_update($user_id, $data)){
		log_activity(array('action_type' => 'update', 'description' =>  'User record has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}else{
	if(db_insert($data)){
		log_activity(array('action_type' => 'add', 'description' =>  'User record has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>