<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);


$dt = date('Y-m-d H:i:s');
$user_id = current_logged_user();
$country_id = $_SESSION['user']['country_id'];
if(!empty($plan_id) && $plan_id != 0){
	$data = array('plan_datetime' => $plan_datetime,'country_id' => $country_id, 'customer_id' => $customer_id, 'product_id' => $product_id, 
				'activity_type' => $activity_type,'updated_on' => $dt,'user_id' => $user_id['id']);
	$query = "update visit_plans set plan_datetime = :plan_datetime, country_id = :country_id, customer_id = :customer_id, product_id = :product_id,
				activity_type = :activity_type, updated_on = :updated_on, user_id= :user_id where id = $plan_id" ;
	if(update_query($query,$data)){
		log_activity(array('action_type' => 'update', 'description' =>  'Visit Plan has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}else{
	$data = array('plan_datetime' => $plan_datetime,'country_id' => $country_id, 'customer_id' => $customer_id, 'product_id' => $product_id, 
				'activity_type' => $activity_type,'created_on' => $dt,'user_id' => $user_id['id']);
	$query = "insert into visit_plans (plan_datetime, country_id, customer_id,product_id,activity_type,created_on,user_id) values 
			(:plan_datetime, :country_id, :customer_id,:product_id,:activity_type, :created_on, :user_id)" ;
	if(insert_query($query,$data)){
		log_activity(array('action_type' => 'add', 'description' =>  'Visit Plan has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>