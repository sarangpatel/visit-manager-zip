<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
//edit form, else add form
if(!empty($user_id) && $user_id != 0){
	$user = get_user($user_id);
	if($user['mobile'] == trim($mobile)){
		echo "true"; //no action
	}else{//** if entered different mobile ( means user editing mobile )
		if(!mobile_exists($mobile)){
			echo "true";
		}else{
			echo "false"; 
		}
	}
}else{
	if(!mobile_exists($mobile)){
		echo "true";
	}else{
		echo "false";
	}
}
?>