
					<div class="row top-buttons ">
						<div class="col-md-12">
							<a href="?page=frontend-create-plan" class="btn  btn-sm btn-primary" >Create Visit Plan</a> &nbsp; &nbsp;
							<a href="?page=frontend-create-report" class="btn  btn-sm btn-primary " >Create New Report</a>
						</div>
					</div>
					<ul class="nav nav-tabs" id="myTab" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="email-tab" data-bs-toggle="tab" href="#upcoming-visit" role="tab" aria-controls="upcoming-visit" aria-selected="true">Upcoming Visits</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="appearance-tab" data-bs-toggle="tab" href="#submitted-report" role="tab" aria-controls="submitted-report" aria-selected="false">Submitted Reports</a>
						</li>
					</ul>
					<div class="tab-content" id="myTabContent">
						<div class="tab-pane fade active show" id="upcoming-visit" role="tabpanel" aria-labelledby="upcoming-tab">
							<h2>Your upcoming visits</h2><hr />
							<?php $visit_plans = list_visit_plans(); ?>
							<?php foreach($visit_plans as $vp){ ?>
							<div class = "plan-list" data-id = "<?php echo $vp['id']; ?>" >
								<div class = "col-md-12"><?php echo date('F j, Y, g:i a' , strtotime($vp['plan_datetime'])); ?> </div>
								<div class = "col-md-12"><?php echo  $vp['customer_name'] .' - '. $vp['location_estate']; ?> </div>
								<div class = "col-md-12"><?php echo  $vp['activity_type']. '(' . $vp['product_name'] . ')'; ?> </div>
								<div class = "col-md-12 mt-2">
									<?php if ($vp['overduetime'] > 0){ ?>
										<button type="button" class="btn btn-sm btn-warning " style = "cursor:default"><span class="badge text-dark">overdue</span></button>
									<?php } ?>
								</div>
							</div>
							<div class  = "col-md-12" >
								<a class = "btn btn-sm btn-primary" href = "?plan_id=<?php echo $vp['id']; ?>&page=frontend-create-plan">Edit</a>
								<a href = "javascript:;"  data-planid = "<?php echo $vp['id']; ?>" class = "planDel btn btn-sm btn-danger" type = "button">Delete</a>
							</div>
							<hr />
							<?php } ?>
						</div>
						<div class="tab-pane fade" id="submitted-report" role="tabpanel" aria-labelledby="submitted-report">
							<h2>Your submitted reports</h2><hr />
							<?php $reports = list_reports(); ?>
							<?php foreach($reports as $vp){ ?>
							<div class = "mb-2 report-list" data-id = "<?php echo $vp['id']; ?>" >
								<div class = "col-md-12"><?php echo date('F j, Y, g:i a' , strtotime($vp['plan_datetime'])); ?> </div>
								<div class = "col-md-12"><?php echo  $vp['customer_name'] .' - '. $vp['location_estate']; ?> </div>
								<div class = "col-md-12"><?php echo  $vp['activity_type']. '(' . $vp['product_name'] . ')'; ?> </div>
							</div>
							<hr />
							<?php } ?>
						</div>
					</div>
