<div class=" frontend-mtop card-body col-md-12">
	<?php $plan_id = isset($_GET['plan_id']) ? $_GET['plan_id'] : 0;  ?>
	<?php $plan_data = get_plan($plan_id);  ?>
	<div class = "frontend-title"><?php echo (isset($_GET['plan_id']) && !empty($_GET['plan_id'])) ? 'Edit ': 'Create' ; ?> Visit Plan</div><hr />
	<form name = "addplan_frm">
		<div class="mb-3">
			
			<label for="" class="form-label">Date/Time<span class  = "mandatory">*</span></label>
			<input type = "hidden" name  = "plan_id" value = "<?php echo $plan_id; ?>" >
			<input type="text" class="form-control" name = "plan_datetime" readonly value = "<?php echo isset($plan_data['plan_datetime']) ?  $plan_data['plan_datetime']: ''  ; ?>" />
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Activity Type<span class  = "mandatory">*</span></label>
			<?php $activity_types = config('activity_types'); ?>
			<select name="activity_type" class="form-select">
				<option value="">Select</option>
				<?php foreach($activity_types as $type){ ?>
				<option value="<?php echo $type; ?>"  <?php echo (isset($plan_data['activity_type']) && $type == $plan_data['activity_type'])  ? 'selected': ''  ; ?> ><?php echo $type; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Customer<span class  = "mandatory">*</span> &nbsp;&nbsp; <a href = "javascript:;" class = "btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#customerAddModal">New Customer</a></label>
			<?php $customers = get_customers(); ?>
			<select name="customer_id" class="form-select">
				<option value="">Select</option>
				<?php foreach($customers as $c){ ?>
				<option value="<?php echo $c['id']; ?>" <?php echo (isset($plan_data['customer_id']) && $c['id'] == $plan_data['customer_id'])  ? 'selected': ''  ; ?>><?php echo '[' . $c['customer_name'] .']' . '- [' . $c['location_estate'] .']' ; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Product<span class  = "mandatory">*</span></label>
			<?php $products = get_products(); ?>
			<select name="product_id" class="form-select">
				<option value="">Select</option>
				<?php foreach($products as $p){ ?>
				<option value="<?php echo $p['id']; ?>" <?php echo (isset($plan_data['product_id']) && $p['id'] == $plan_data['product_id'])  ? 'selected': ''  ; ?>><?php echo $p['product_name']; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3 ">
			<?php if(empty($plan_data['is_report_submitted'])) { ?>
			<button class="btn btn-primary" type="submit">Submit</button>
			<a  href = "?page=frontend-create-report&plan_id=<?php echo $plan_id; ?>"   class="btn btn-primary" type="button">Submit Report</a>
			<?php }else{ ?>
				<?php if($plan_data['is_report_submitted'] == 1) { $report = get_report_by_planid($plan_id) ?>
					<a  href = "?page=frontend-create-report&report_id=<?php echo $report['id']; ?>"   class="btn btn-primary" type="button">View Report</a>
				<?php } ?>
			<?php } ?>
		</div>
	</form>
</div>
<?php require_once('customer-modal.php'); ?>