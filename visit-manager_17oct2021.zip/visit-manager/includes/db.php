<?php
try{
	$db = config('database');
	$conn = new PDO("mysql:host=" . $db['host'] . ";dbname=" .$db['dbname'], $db['username'], $db['password'], array( PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC));
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	//$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
	$conn->exec("SET TIME_ZONE ='+08:00';"); //singapore
}catch(PDOException $exception){
	echo "Connection error: " . $exception->getMessage();
	exit;
}
?>