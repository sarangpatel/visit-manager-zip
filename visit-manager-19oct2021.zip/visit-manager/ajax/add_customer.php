<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);


$dt = date('Y-m-d H:i:s');
$user_id = current_logged_user();
$country_id = $_SESSION['user']['country_id'];

if(!empty($customer_id) && $customer_id != 0){
	$data = array('customer_name' => $customer_name,'country_id' => $country_id, 'location_estate' => $location_estate,'contact_person' => $contact_person, 'mobile' => $mobile, 'updated_on' => $dt,'updated_by' => $user_id['id']);
	$query = "update customers set customer_name = :customer_name, country_id = :country_id, location_estate = :location_estate,contact_person = :contact_person,
	mobile = :mobile, updated_on = :updated_on, updated_by= :updated_by where id = $customer_id" ;
	if(update_query($query,$data)){
		log_activity(array('action_type' => 'update', 'description' =>  'Customer has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}else{
	$data = array('customer_name' => $customer_name,'country_id' => $country_id, 'location_estate' => $location_estate,'contact_person' => $contact_person, 'mobile' => $mobile,'created_by' => $user_id['id'],'created_on' => $dt);
	$query = "insert into customers (customer_name, country_id, location_estate,contact_person,mobile,created_by, created_on) values (:customer_name, :country_id, :location_estate, :contact_person, :mobile, :created_by, :created_on)" ;
	if($id = insert_query($query,$data)){
		$customer = get_customer($id);
		log_activity(array('action_type' => 'add', 'description' =>  'Customer has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success', 'data' => array('customer_id' => $id, 'customer_name' =>  "[{$customer['location_estate']}] - [{$customer['customer_name']}]" )));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>