<style>
/*#country-list{float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
#country-list li{padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
#country-list li:hover{background:#ece3d2;cursor: pointer;}
*/
.autocomplete-dropdown {
  background-color: #F8F8F8;
  position: absolute;
  box-shadow: 0 1px 3px 0px;
  border-radius: 3px;
  border: 1px solid #FAFAFA;
  z-index: 100;
  max-height: 250px;
  overflow-y: auto;
  width:94%;
}

.autocomplete-dropdown ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

.autocomplete-dropdown ul li {
  padding: 4px 12px;
}

.autocomplete-dropdown ul li:focus,
.autocomplete-dropdown ul li:hover {
  background-color: #F0F0F0;
  cursor: pointer;
}




</style>
		   <div class="modal fade" id="customerAddModal" role="dialog" tabindex="-1">
			  <div class="modal-dialog">
				<div class="modal-content">
				<form accept-charset="utf-8" name = "addcustomer_frm" >
					  <input type ="hidden" name = "customer_id" value = "0">
					  <div class="modal-header">
						<h5 class="modal-title">Add Customer</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					  </div>
					  <div class="modal-body text-start">
							<div class="mb-3">
								<label class="form-label">Customre Name<span class= "mandatory">*</span></label>
								<input type="text" name="customer_name" class="form-control" autocomplete = "off" >
								<div id="suggesstion-box" class = "autocomplete-dropdown"></div>
							</div>
							<div class="mb-3">
								<label class="form-label">Location / Estate<span class= "mandatory">*</span></label>
								<input type="text" name="location_estate" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Contact Person<span class= "mandatory">*</span></label>
								<input type="text" name="contact_person" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Phone Number<span class= "mandatory">*</span></label>
								<input type="text" name="mobile" class="form-control">
								<small class="form-text text-muted">For Ex:  +658454049404</small>
							</div>
					  </div>
					  <div class="modal-footer">
						<button type="submit" class="btn btn-primary" >Submit</button>
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					  </div>
				</form>
				</div>
			  </div>
			</div>
