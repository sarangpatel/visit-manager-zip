<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);
//update, else insert
if(!empty($user_id) && $user_id != 0){
	if(db_delete($user_id)){
		log_activity(array('action_type' => 'delete', 'description' =>  'User record has been deleted by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}else{
	echo json_encode(array('error' => true, 'msg' => 'error'));
}
?>