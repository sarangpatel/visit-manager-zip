<style>
	.dt-buttons{
	margin: 0px 0px 0px 18px;
    float: right;
	}

	.dt-buttons > button{
	color: #fff !important;
    background-color: #0d6efd !important;
    border-color: #0d6efd !important;
    display: inline-block !important;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    text-align: center !important;
    text-decoration: none !important;
    vertical-align: middle !important;
    cursor: pointer !important;
    border-radius: .25rem !important;
	}
</style>
			<div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Activities</h3>
                    </div>
                    <div class="box box-primary">
                        <div class="box-body">
							<div class  = "mb-2 mt-2">Filter by:</div>
							<form name = "activitysearch_frm" >
								<div class = "row">
										<div class  = "col-md-3 mb-2 mt-2">
											<label >Start Date &nbsp;  </label><input type = "text" name = "start_date" class = "form-control" />
										</div>
										<div class  = "col-md-3 mb-2 mt-2">
											<label >End Date &nbsp;  </label><input type = "text" name = "end_date" class = "form-control"  />
										</div>
										<div class  = "col-md-3 mb-2 mt-2">
											<label >User &nbsp;  </label>
											<select name  = "user_id" class = "form-select" >
												<option value = "">Select</option>
												<?php $users  = get_users('field_team_member'); ?>
												<?php foreach($users as $user){ ?>
													<option value = "<?php echo $user['id']; ?>"><?php echo $user['name']; ?></option>
												<?php } ?>
											</select>
										</div>
										<div class  = "col-md-3 mb-2 mt-2">
											<label >Country &nbsp;  </label>
											<select name  = "country_id"  class = "form-select">
												<option value = "">Select</option>
												<?php $countries  = get_countries(); ?>
												<?php foreach($countries as $country){ ?>
													<option value = "<?php echo $country['id']; ?>"><?php echo $country['country_name']; ?></option>
												<?php } ?>
											</select>
										</div>
								</div>
							</form>
                            <table width="100%" class="table table-bordered table-hover" id="activityTable">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Country</th>
                                        <th>Action Type</th>
                                        <th>Text</th>
                                        <th>Date/Time</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>