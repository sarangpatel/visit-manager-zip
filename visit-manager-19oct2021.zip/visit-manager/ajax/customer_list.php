<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';


if(!empty($_GET["query"])){
	$query ="SELECT * FROM customers WHERE customer_name like '%" . $_GET["query"] . "%' ORDER BY customer_name LIMIT 0,300";
	$data  = select_query($query);
	$return_data = array();
	if(!empty($data)){
		 foreach($data as $c) { 
			 $return_data[] = array("value" => $c["customer_name"], "data" => $c["id"]);
		 }
	}
	$final_return['suggestions'] =  $return_data;
	echo json_encode($final_return);
	exit;
}
?>