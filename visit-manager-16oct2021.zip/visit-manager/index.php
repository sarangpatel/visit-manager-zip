<?php
require 'includes/config.php';
require 'includes/db.php';
require 'includes/functions.php';
init();