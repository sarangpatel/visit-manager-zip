<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);

//edit form, else add form
if(!empty($user_id) && $user_id != 0){
	$user = get_user($user_id);
	if($user['email'] == trim($email)){
		echo "true"; //no action
	}else{//** if entered different email ( means user editing email )
		if(!email_exists($email)){
			echo "true";
		}else{
			echo "false"; 
		}
	}
}else{
	if(!email_exists($email)){
		echo "true";
	}else{
		echo "false";
	}

}


?>