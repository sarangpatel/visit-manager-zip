<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);

$dt = date('Y-m-d H:i:s');
$user_id = current_logged_user();
if(!empty($country_id) && $country_id != 0){
	$data = array('country_name' => $country_name, 'is_active' => $is_active,'updated_on' => $dt,'updated_by' => $user_id['id']);
	$query = "update countries set country_name = :country_name, is_active = :is_active,
	 updated_on = :updated_on, updated_by= :updated_by where id = $country_id" ;
	if(update_query($query,$data)){
		log_activity(array('action_type' => 'update', 'description' =>  'Country records has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}else{
	$data = array('country_name' => $country_name, 'is_active' => $is_active,'created_by' => $user_id['id'],'created_on' => $dt);
	$query = "insert into countries (country_name, is_active,created_by, created_on) values (:country_name, :is_active, :created_by, :created_on)" ;
	if(insert_query($query,$data)){
		log_activity(array('action_type' => 'add', 'description' =>  'Country record has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>