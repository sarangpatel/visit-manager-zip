            <div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Products
                            <a href="#" class="btn  btn-primary float-end " data-bs-toggle="modal" data-bs-target="#productAddModal"> Add Product</a>
                        </h3>
                    </div>
                    <div class="box box-primary">
                        <div class="box-body">
                            <table width="100%" class="table table-bordered table-hover" id="productTable">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Country</th>
                                        <th>Status</th>
                                        <th>Created on</th>
                                        <th></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

		   <div class="modal fade" id="productAddModal" role="dialog" tabindex="-1">
			  <div class="modal-dialog">
				<div class="modal-content">
				<form accept-charset="utf-8" name = "addproduct_frm" id  = "adduser_frm">
					  <input type ="hidden" name = "product_id" value = "0">
					  <div class="modal-header">
						<h5 class="modal-title">Add / Edit Product</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					  </div>
					  <div class="modal-body text-start">
							<div class="mb-3">
								<label class="form-label">Name<span class= "mandatory">*</span></label>
								<input type="text" name="product_name" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Country<span class= "mandatory">*</span></label>
								<select name = "country_id" class="form-control">
									<option value = "">Please Select</option>
									<?php $countries  = get_countries(); ?>
									<?php foreach($countries as $country){ ?>
										<option value = "<?php echo $country['id']; ?>"><?php echo $country['country_name']; ?></option>
									<?php } ?>
								</select>
							</div>
							<div class="mb-3 " >
								<label class="form-label">Status<span class= "mandatory">*</span></label>
								<select name = "is_active" class="form-control">
									<option value = "1" selected>Active</option>
									<option value = "0" >In-Active</option>
								</select>
							</div>
					  </div>
					  <div class="modal-footer">
						<button type="submit" class="btn btn-primary" >Submit</button>
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					  </div>
				</form>
				</div>
			  </div>
			</div>
