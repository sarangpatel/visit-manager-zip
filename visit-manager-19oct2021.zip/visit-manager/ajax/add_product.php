<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);


$dt = date('Y-m-d H:i:s');
$user_id = current_logged_user();
if(!empty($product_id) && $product_id != 0){
	$data = array('product_name' => $product_name,'country_id' => $country_id, 'is_active' => $is_active,'updated_on' => $dt,'updated_by' => $user_id['id']);
	$query = "update products set product_name = :product_name, country_id = :country_id, is_active = :is_active,
	 updated_on = :updated_on, updated_by= :updated_by where id = $product_id" ;
	if(update_query($query,$data)){
		log_activity(array('action_type' => 'update', 'description' =>  'Product records has been updated by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}else{
	$data = array('product_name' => $product_name,'country_id' => $country_id, 'is_active' => $is_active,'created_by' => $user_id['id'],'created_on' => $dt);
	$query = "insert into products (product_name, country_id, is_active,created_by, created_on) values (:product_name, :country_id, :is_active, :created_by, :created_on)" ;
	if(insert_query($query,$data)){
		log_activity(array('action_type' => 'add', 'description' =>  'Product record has been added by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}

}
?>