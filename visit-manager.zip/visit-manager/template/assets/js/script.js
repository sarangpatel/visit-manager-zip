/*------------------------------------------------------------------
* Bootstrap Simple Admin Template
* Version: 3.0
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-------------------------------------------------------------------*/
(function() {
    'use strict';

    // Toggle sidebar on Menu button click
    $('#sidebarCollapse').on('click', function() {
        $('#sidebar').toggleClass('active');
        $('#body').toggleClass('active');
    });

    // Auto-hide sidebar on window resize if window size is small
    // $(window).on('resize', function () {
    //     if ($(window).width() <= 768) {
    //         $('#sidebar, #body').addClass('active');
    //     }
    // });
})();

var globalKeepLoggedIn = (60 * 60 * 24) * 14; //14 days

$(function() {
	$.validator.addMethod("nameChars", function(value, element) {
	  return this.optional(element) || /^[a-z0-9\-\s]+$/i.test(value);
	}, "Name must contain only letter, numbers or dashes");

	$.validator.addMethod("mobileNumber", function(value, element) {
	  return this.optional(element) || /^\+[0-9\+]+$/i.test(value);
	}, "Digits allowed only. Format will be +65845404904");


	// Initialize form validation on the registration form.
	// It has the name attribute "registration"
	$("form[name='adduser_frm']").validate({
		// Specify validation rules
		rules: {
			name: {
				required:true,
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			email: {
				required: true,
				email: true,
				normalizer: function(value) {
					return $.trim(value);
				},
				remote: {
					url: SITE_URL + 'ajax/email_exists.php',
					type: "POST",
					dataType: "json",
					data:{
						"email": function() {
							return $('#adduser_frm').find("input[name='email']").val();
						},
						"user_id": function(){
							return $('#adduser_frm').find("input[name='user_id']").val()
						}
					},
					cache: false
				}
			},
			mobile: {
				required: true,
				minlength: 12,
				mobileNumber:true,
				normalizer: function(value) {
					return $.trim(value);
				},

				remote: {
					url: SITE_URL + 'ajax/mobile_exists.php',
					type: "POST",
					dataType: "json",
					data:{
						"mobile": function() {
							return $('#adduser_frm').find("input[name='mobile']").val();
						},
						"user_id": function(){
							return $('#adduser_frm').find("input[name='user_id']").val()
						}
					},
					cache: false
				}
			},
			country_id: {
				required: true
			},
			account_type:{
				required: true
			}
		},
		messages: {
			email: {
				remote: "Email already exists, please try different."
			},
			mobile: {
				remote: "Mobile already exists, please try different."
			}
		},
		submitHandler: function(form) {
			console.log("formsubmitted");
			let msg = parseInt($("form[name='adduser_frm']").find("input[name='user_id']").val()) === 0 ? 'added' : 'updated'; 
			console.log($(form).attr('name'));
			let name  =  $(form).find("input[name='name']").val();
			let email  =  $(form).find("input[name='email']").val();
			let mobile =  $(form).find("input[name='mobile']").val();
			let country_id  =  $(form).find("select[name='country_id']").val();
			let account_type  =  $(form).find("select[name='account_type']").val();
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );

			$.ajax({
					url : SITE_URL + 'ajax/add_user.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal('Success!', 'User ' + msg + ' successfully.', "success");
				//$("form[name='adduser_frm']").validate().resetForm();
				$("form[name='adduser_frm']")[0].reset();
				var instance = new $.fn.dataTable.Api( '#userTable' );
				instance.ajax.reload();
				$('#userAddModal').modal('hide');
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Alert!", textStatus, "error");
			});
			return false;
		}
	});


	$("form[name='frmLogin']").validate({
		// Specify validation rules
		rules: {
			email_mobile: {
				required: true,
				email: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function(form) {
			console.log('form login');
			$.ajax({
					url : SITE_URL + 'ajax/send_otp.php',
					type: 'POST',
					dataType: 'json',
					data: {email_mobile: $("form[name='frmLogin']").find("input[name='email_mobile']").val()}
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					$.trim($("form[name='frmOtp']").find("input[name='email_mobile']").val($("form[name='frmLogin']").find("input[name='email_mobile']").val())),
					$('#login').hide();
					$('#otp').show();

				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
			});
			return false;
		}
	});

	$("form[name='frmOtp']").validate({
		// Specify validation rules
		rules: {
			otp: {
				required: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function(form) {
			console.log('form otp');
			$.ajax({
					url : SITE_URL + 'ajax/verify_otp.php',
					type: 'POST',
					dataType: 'json',
					data: {email_mobile: $.trim($("form[name='frmOtp']").find("input[name='email_mobile']").val()), otp: $("form[name='frmOtp']").find("input[name='otp']").val()}
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					$('#login').hide();
					$('#otp').show();
					setCookie('logged_in', 1, globalKeepLoggedIn); //14 days
					setCookie('logged_user_id', data.data.user_id , globalKeepLoggedIn);//14 days
					window.location.href = SITE_URL;
					swal("Success!", "Logged-in successfully.", "success");
				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
			});
			return false;
		}
	});


	$("form[name='addproduct_frm']").validate({
		// Specify validation rules
		rules: {
			product_name: {
				required: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			country_id: {
				required: true
			}
		},
		submitHandler: function(form) {
			console.log('form product');
			let msg = parseInt($("form[name='addproduct_frm']").find("input[name='product_id']").val()) === 0 ? 'added' : 'updated'; 
			$.ajax({
					url : SITE_URL + 'ajax/add_product.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal('Success!', 'Product ' + msg + ' successfully.', "success");
				//$("form[name='adduser_frm']").validate().resetForm();
				$("form[name='addproduct_frm']")[0].reset();
				var instance = new $.fn.dataTable.Api( '#productTable' );
				instance.ajax.reload();
				$('#productAddModal').modal('hide');
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Alert!", textStatus, "error");
			});
			return false;
		}
	});

	$("form[name='addcountry_frm']").validate({
		// Specify validation rules
		rules: {
			country_name: {
				required: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function(form) {
			console.log('form country');
			let msg = parseInt($("form[name='addcountry_frm']").find("input[name='country_id']").val()) === 0 ? 'added' : 'updated'; 
			$.ajax({
					url : SITE_URL + 'ajax/add_country.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize()
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal('Success!', 'Country ' + msg + ' successfully.', "success");
				//$("form[name='adduser_frm']").validate().resetForm();
				$("form[name='addcountry_frm']")[0].reset();
				var instance = new $.fn.dataTable.Api( '#countryTable' );
				instance.ajax.reload();
				$('#countryAddModal').modal('hide');
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Alert!", textStatus, "error");
			});
			return false;
		}
	});


	$('#userTable').on('click', '.editLink', function (evt) {
			evt.preventDefault();
			let user_id = $(this).data('userid');
			$("form[name='adduser_frm']").find("input[name='user_id']").val($(this).data('userid'));
			$("form[name='adduser_frm']").find("input[name='name']").val($(this).data('name'));
			$("form[name='adduser_frm']").find("input[name='mobile']").val($(this).data('mobile'));
			$("form[name='adduser_frm']").find("input[name='email']").val($(this).data('email'));
			$("form[name='adduser_frm']").find("select[name='country_id']").val($(this).data('name'));
			$("form[name='adduser_frm']  select[name='country_id'] option[value='" + $(this).data('countryid')  + "']").prop('selected', true);
			$("form[name='adduser_frm']  select[name='account_type'] option[value='" + $(this).data('accounttype')  + "']").prop('selected', true);
			$("form[name='adduser_frm']  select[name='is_active'] option[value='" + $(this).data('isactive')  + "']").prop('selected', true);
			$('#userAddModal').modal('show');
		return false;
	});

	$('#userTable').on('click', '.delLink', function (evt) {
			evt.preventDefault();
			let user_id = $(this).data('userid');
			swal({
				title: "Are you sure ??",
				text: "", 
				icon: "warning",
				buttons: true,
				dangerMode: true
			})
			 .then((willDelete) => {
				  if (willDelete) {
					$.ajax({
							url : SITE_URL + 'ajax/del_user.php',
							type: 'POST',
							dataType: 'json',
							data: {user_id: user_id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "User deleted successfully.", "success");
						var instance = new $.fn.dataTable.Api( '#userTable' );
						instance.ajax.reload();
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
				  } else {
					//swal("Your imaginary file is safe!");
				  }
			});
			return false;
	});


	$('#countryTable').on('click', '.editLink', function (evt) {
			evt.preventDefault();
			let country_id = $(this).data('countryid');
			$("form[name='addcountry_frm']").find("input[name='country_id']").val(country_id);
			$("form[name='addcountry_frm']").find("input[name='country_name']").val($(this).data('name'));
			$("form[name='addcountry_frm']  select[name='is_active'] option[value='" + $(this).data('isactive')  + "']").prop('selected', true);
			$('#countryAddModal').modal('show');
		return false;
	});

	$('#countryTable').on('click', '.delLink', function (evt) {
			evt.preventDefault();
			let country_id = $(this).data('countryid');
			swal({
				title: "Are you sure ??",
				text: "", 
				icon: "warning",
				buttons: true,
				dangerMode: true
			})
			 .then((willDelete) => {
				  if (willDelete) {
					$.ajax({
							url : SITE_URL + 'ajax/del_country.php',
							type: 'POST',
							dataType: 'json',
							data: {country_id: country_id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "Country deleted successfully.", "success");
						var instance = new $.fn.dataTable.Api( '#countryTable' );
						instance.ajax.reload();
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
				  } else {
					//swal("Your imaginary file is safe!");
				  }
			});
			return false;
	});


	$('#countryAddModal').on('hide.bs.modal', function (){
		$("form[name='addcountry_frm']").find("input[name='country_id']").val(0);
		$("form[name='addcountry_frm']").validate().resetForm();
		$("form[name='addcountry_frm']")[0].reset();
		
	});


	$('#userAddModal').on('hide.bs.modal', function (){
		$("form[name='adduser_frm']").find("input[name='user_id']").val(0);
		$("form[name='adduser_frm']").validate().resetForm();
		$("form[name='adduser_frm']")[0].reset();
		
	});

	/*** PRODUCT ********/

	$('#productTable').on('click', '.editLink', function (evt) {
			evt.preventDefault();
			let product_id = $(this).data('productid');
			$("form[name='addproduct_frm']").find("input[name='product_id']").val(product_id);
			$("form[name='addproduct_frm']").find("input[name='product_name']").val($(this).data('name'));
			$("form[name='addproduct_frm']  select[name='country_id'] option[value='" + $(this).data('countryid')  + "']").prop('selected', true);
			$("form[name='addproduct_frm']  select[name='is_active'] option[value='" + $(this).data('isactive')  + "']").prop('selected', true);
			$('#productAddModal').modal('show');
		return false;
	});

	$('#productTable').on('click', '.delLink', function (evt) {
			evt.preventDefault();
			let product_id = $(this).data('productid');
			swal({
				title: "Are you sure ??",
				text: "", 
				icon: "warning",
				buttons: true,
				dangerMode: true
			})
			 .then((willDelete) => {
				  if (willDelete) {
					$.ajax({
							url : SITE_URL + 'ajax/del_product.php',
							type: 'POST',
							dataType: 'json',
							data: {product_id: product_id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "Product deleted successfully.", "success");
						var instance = new $.fn.dataTable.Api( '#productTable' );
						instance.ajax.reload();
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
				  } else {
					//swal("Your imaginary file is safe!");
				  }
			});
			return false;
	});


	$('#productAddModal').on('hide.bs.modal', function (){
		$("form[name='addproduct_frm']").find("input[name='product_id']").val(0);
		$("form[name='addproduct_frm']").validate().resetForm();
		$("form[name='addproduct_frm']")[0].reset();
		
	});


	/*** PRODUCT ***********/


});

//********** START TABLES ****************/
$(document).ready(function(){
   $('#userTable').DataTable({
		'responsive': true,
		'pageLength': 10,
		'searching': true,
		'ordering': true,
		'processing': true,
		'serverSide': true,
		'serverMethod': 'post',
		'ajax': {
		  'url': SITE_URL + 'ajax/' +  'list_user.php'
		},
		'columns': [
		 { data: 'name' },
		 { data: 'email' },
		 { data: 'mobile' },
		 { data: 'countryname' },
		 { data: 'is_active' },
		 { data: 'created_on' },
		 { data: 'action' }
		],
		'columnDefs': [
			{ orderable: false, targets: -1 },
		],
		'order': [[ 5, "desc" ]],
	});

	$('#userAddModal').on('show.bs.modal', function (e) {
		console.log('modal show');

	});

	$('#userAddModal').on('shown.bs.modal', function (){
		console.log('modal shown');
	});

   $('#productTable').DataTable({
		'responsive': true,
		'pageLength': 10,
		'searching': true,
		'ordering': true,
		'processing': true,
		'serverSide': true,
		'serverMethod': 'post',
		'ajax': {
		  'url': SITE_URL + 'ajax/' +  'list_product.php'
		},
		'columns': [
		 { data: 'product_name' },
		 { data: 'countryname' },
		 { data: 'is_active' },
		 { data: 'created_on' },
		 { data: 'action' }
		],
		'columnDefs': [
			{ orderable: false, targets: -1 },
		],
		'order': [[ 3, "desc" ]],
	});

   $('#countryTable').DataTable({
		'responsive': true,
		'pageLength': 10,
		'searching': true,
		'ordering': true,
		'processing': true,
		'serverSide': true,
		'serverMethod': 'post',
		'ajax': {
		  'url': SITE_URL + 'ajax/' +  'list_country.php'
		},
		'columns': [
		 { data: 'country_name' },
		 { data: 'is_active' },
		 { data: 'created_on' },
		 { data: 'action' }
		],
		'columnDefs': [
			{ orderable: false, targets: -1 },
		],
		'order': [[ 2, "desc" ]],
	});


});
//********** END TABLES ****************/
