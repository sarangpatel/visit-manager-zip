<?php
require '../includes/config.php';
require '../includes/db.php';
require '../includes/functions.php';
extract($_POST);

$user_id = current_logged_user();
if(!empty($plan_id) && $plan_id != 0){
	$data = array('plan_id' => $plan_id);
	$query = "DELETE from visit_plans where id = :plan_id " ;
	if(delete_query($query,$data)){
		log_activity(array('action_type' => 'delete', 'description' =>  'Visit Plan has been deleted by ' . $_SESSION['user']['name']));
		echo json_encode(array('error' => false, 'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => 'error'));
	}
}
?>