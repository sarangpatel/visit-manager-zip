<?php
require  __DIR__  . '/includes/config.php';
require  __DIR__  .  '/includes/db.php';
require  __DIR__  . '/includes/functions.php';
$today = date('Y-m-d');
$query = "SELECT vp.*, u.name, u.email,c.customer_name, p.product_name from visit_plans vp inner join users u on u.id = vp.user_id   
           inner join products p on p.id = vp.product_id inner join customers c on c.id = vp.customer_id 
           WHERE vp.plan_datetime >= '$today 00:00:00' and  vp.plan_datetime <=  '$today 23:59:59' and u.is_deleted = 0 and u.is_active = 1 order by vp.id desc limit 300 ";
$data = select_query($query);
$result  = array();
foreach($data as $d){
	$result[$d['user_id']][] = $d;
}


foreach($result as $res){
	$table = '<table border= "1" style = "width:100%;  border-collapse: collapse;" cellpadding = "2" cellspacing = "2"><tr><th>Plan Date</th><th>Activity Type</th><th>Customer Name</th><th>Product Name</th></tr>';
	foreach($res as $r){
		$emp_name = $r['name'];
		$email = $r['email'];
		$table .= get_table_row($r);
	}
	$table .= '</table>';
	$content = get_email($table, $emp_name);
	send_email('Your planned visits for today', $email, $content);
}
//echo '<PRE>';
//print_r($result);exit;


function get_table_row($row){
	$str =  "<tr><td width = '25%'>{$row['plan_datetime']}</td><td width = '25%'>{$row['activity_type']}</td><td width = '25%'>{$row['customer_name']}</td><td width = '25%'>{$row['product_name']}</td></tr>";
	return $str;
}

function get_email($table,$emp_name){
	$str = "
	<!DOCTYPE html>
	<html lang=\"en\">
	 <head>
	  <meta charset=\"UTF-8\">
	  <title>Email</title>
	<style>
		th, td {
		  padding: 15px;
		  text-align: left;
		}
	</style>
	 </head>
	 <body>
	 <div>Dear $emp_name,</div><br />
	  <div>Please find below plans for today:</div> <br /><br />
	  $table
	  <br /><br />
	  Thanks,<br />
	  plantation-sales.ap.basf.com
	 </body>
	</html>";
	return $str;
}

function send_email($subject,$to,$content){
	$headers = "From: admin@plantation-sales.ap.basf.com   \r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
	mail($to, $subject, $content, $headers);
}


?>