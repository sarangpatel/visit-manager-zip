							  <link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">

							<div class=" frontend-mtop card-body col-md-12">
								<div class = "frontend-title">Create Visit Plan</div><hr />
								<form name = "addplan_frm">
									<div class="mb-3">
										<label for="" class="form-label">Date/Time<span class  = "mandatory">*</span></label>
										<input type="text" class="form-control" name = "plan_datetime" >
									</div>
									<div class="mb-3">
										<label for="" class="form-label">Activity Type<span class  = "mandatory">*</span></label>
										<?php $activity_types = config('activity_types'); ?>
										<select name="activity_type" class="form-select">
											<option value="">Select</option>
											<?php foreach($activity_types as $type){ ?>
											<option value="<?php echo $type; ?>"><?php echo $type; ?></option>
											<?php  } ?>
										</select>
									</div>
									<div class="mb-3">
										<label for="" class="form-label">Customer<span class  = "mandatory">*</span> &nbsp;&nbsp; <a href = "#" class = "btn btn-primary btn-sm new-cust-link">New Customer</a></label>
										<?php $activity_types = config('activity_types'); ?>
										<select name="customer_id" class="form-select">
											<option value="">Select</option>
											<?php foreach($activity_types as $type){ ?>
											<option value="<?php echo $type; ?>"><?php echo $type; ?></option>
											<?php  } ?>
										</select>
									</div>
									<div class="mb-3">
										<label for="" class="form-label">Product<span class  = "mandatory">*</span></label>
										<?php $products = get_products(); ?>
										<select name="product_id" class="form-select">
											<option value="">Select</option>
											<?php foreach($products as $p){ ?>
											<option value="<?php echo $p['id']; ?>"><?php echo $p['product_name']; ?></option>
											<?php  } ?>
										</select>
									</div>
									<div class="mb-3 ">
										<button class="btn btn-primary" type="submit">Submit</button>
									</div>
								</form>
							</div>
