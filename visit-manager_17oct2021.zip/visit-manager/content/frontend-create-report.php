<div class=" frontend-mtop card-body col-md-12">
	<?php $plan_id = isset($_GET['plan_id']) ? $_GET['plan_id'] : 0;  ?>
	<?php $report_id = isset($_GET['report_id']) ? $_GET['report_id'] : 0;  ?>

	<?php
		if(!empty($report_id)){
			$plan_data = get_report($report_id);
		}else{
			if(!empty($plan_id)){
				$plan_data = get_plan($plan_id); 
			}
		}

	?>
	<div class = "frontend-title"><?php echo (isset($_GET['report_id']) && !empty($_GET['report_id'])) ? 'View ': 'Create' ; ?> Report</div><hr />
	<form name = "addreport_frm">
		<div class="mb-3">
			<label for="" class="form-label">Date/Time<span class  = "mandatory">*</span></label>
			<input type = "hidden" name  = "report_id" value = "<?php echo $report_id; ?>" >
			<input type = "hidden" name  = "plan_id" value = "<?php echo $plan_id; ?>" >
			<input type="text" class="form-control" name = "plan_datetime" readonly value = "<?php echo isset($plan_data['plan_datetime']) ?  $plan_data['plan_datetime']: ''  ; ?>" />
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Activity Type<span class  = "mandatory">*</span></label>
			<?php $activity_types = config('activity_types'); ?>
			<select name="activity_type" class="form-select">
				<option value="">Select</option>
				<?php foreach($activity_types as $type){ ?>
				<option value="<?php echo $type; ?>"  <?php echo (isset($plan_data['activity_type']) && $type == $plan_data['activity_type'])  ? 'selected': ''  ; ?> ><?php echo $type; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Customer<span class  = "mandatory">*</span> &nbsp;&nbsp;<a href = "javascript:;" class = "btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#customerAddModal">New Customer</a></label>
			<?php $customers = get_customers(); ?>
			<select name="customer_id" class="form-select">
				<option value="">Select</option>
				<?php foreach($customers as $c){ ?>
				<option value="<?php echo $c['id']; ?>" <?php echo (isset($plan_data['customer_id']) && $c['id'] == $plan_data['customer_id'])  ? 'selected': ''  ; ?>><?php echo '[' . $c['customer_name'] .']' . '- [' . $c['location_estate'] .']' ; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Product<span class  = "mandatory">*</span></label>
			<?php $products = get_products(); ?>
			<select name="product_id" class="form-select">
				<option value="">Select</option>
				<?php foreach($products as $p){ ?>
				<option value="<?php echo $p['id']; ?>" <?php echo (isset($plan_data['product_id']) && $p['id'] == $plan_data['product_id'])  ? 'selected': ''  ; ?>><?php echo $p['product_name']; ?></option>
				<?php  } ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="" class="form-label textdata">Result<span class  = "mandatory">*</span></label>
			<textarea class="form-control" name = "result" rows = "8"><?php echo isset($plan_data['result']) ?  $plan_data['result']: ''  ; ?></textarea>
		</div>
		<div class="mb-3">
			<label for="" class="form-label textdata">Next Steps<span class  = "mandatory">*</span></label>
			<textarea class="form-control" name = "next_steps"  rows = "8"><?php echo isset($plan_data['next_steps']) ?  $plan_data['next_steps']: ''  ; ?></textarea>
		</div>
		<?php if(empty($report_id)) { ?>
		<div class="mb-3 ">
			<button class="btn btn-primary" type="submit">Submit</button>
		</div>
		<?php } ?>
	</form>
</div>
<?php require_once('customer-modal.php'); ?>