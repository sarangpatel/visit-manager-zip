<?php

/**
 * Displays site name.
 */
function site_name()
{
    echo config('name');
}

/**
 * Displays site url provided in config.
 */
function site_url()
{
    echo config('site_url');
}

/**
 * Displays site version.
 */
function site_version()
{
    echo config('version');
}

/**
 * Website navigation.
 */
function nav_menu($sep = ' | ')
{
    $nav_menu = '';
    $nav_items = config('nav_menu');
    
    foreach ($nav_items as $uri => $name) {
        $query_string = str_replace('page=', '', $_SERVER['QUERY_STRING'] ?? '');
        $class = $query_string == $uri ? ' active' : '';
        $url = config('site_url') . '/' . (config('pretty_uri') || $uri == '' ? '' : '?page=') . $uri;
        
        // Add nav item to list. See the dot in front of equal sign (.=)
        $nav_menu .= '<a href="' . $url . '" title="' . $name . '" class="item ' . $class . '">' . $name . '</a>' . $sep;
    }

    echo trim($nav_menu, $sep);
}

/**
 * Displays page title. It takes the data from
 * URL, it replaces the hyphens with spaces and
 * it capitalizes the words.
 */
function page_title()
{
    $page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'Home';

    echo ucwords(str_replace('-', ' ', $page));
}

/**
 * Displays page content. It takes the data from
 * the static pages inside the pages/ directory.
 * When not found, display the 404 error page.
 */
function page_content()
{
    $page = isset($_GET['page']) ? $_GET['page'] : 'home';
    $path = getcwd() . '/' . config('content_path') . '/' . $page . '.php';

    if (! file_exists($path)) {
        $path = getcwd() . '/' . config('content_path') . '/404.php';
    }
    //echo file_get_contents($path);
	include($path);
}

function get_countries(){
	global $conn;
	try {
		$query = "SELECT id,country_name,country_iso FROM countries WHERE is_active = 1 order by country_name asc";
		$stmt = $conn->prepare($query);
		$stmt->execute();
		$num = $stmt->rowCount();
		if($num > 0){
			return $stmt->fetchAll();
		}
	} catch (Throwable $e) {
		log_errors($e->getMessage());
	}
}


//return true if email found, else false
function email_exists($email){
	global $conn;
	try {
		$query = "SELECT id from users WHERE email = ? limit 1";
		$stmt = $conn->prepare($query);
		$stmt->execute(array($email));
		$num = $stmt->rowCount();
		if($num > 0){
			return true;
		}else{
			return false;
		}
	} catch (Throwable $e) {
		log_errors($e->getMessage());
	}
}

//return true if email found, else false
function email_mobile_exists($email_mobile){
	global $conn;
	$query = "SELECT id from users WHERE email = ? AND is_deleted = 0 AND is_active = 1 limit 1";
	$stmt = $conn->prepare($query);
	$stmt->execute(array($email_mobile));
	$num = $stmt->rowCount();
	if($num > 0){
		return true;
	}else{
		return false;
	}
}


//get user from id
function get_user($id){
	global $conn;
	$query = "SELECT * from users WHERE id = ? limit 1";
	$stmt = $conn->prepare($query);
	$stmt->execute(array($id));
	return $stmt->fetch();
}

//return true if email found, else false
function mobile_exists($mobile){
	global $conn;
	try {
		$query = "SELECT id from users WHERE mobile = ? limit 1";
		$stmt = $conn->prepare($query);
		$stmt->execute(array($mobile));
		$num = $stmt->rowCount();
		if($num > 0){
			return true;
		}else{
			return false;
		}
	} catch (Throwable $e) {
		log_errors($e->getMessage());
	}
}

function current_logged_user($data = array()){
	return array('id' => $_SESSION['user']['id']);
}

function db_delete($id){
	global $conn;
	$dt = date('Y-m-d H:i:s');
	$user = current_logged_user();
	$user_id = $user['id'];
	try {
		$query = "update users set is_deleted = 1, updated_on = '$dt', updated_by= $user_id where id = ?" ;
		$stmt = $conn->prepare($query);
		$stmt->execute(array($id));
		return 1;
	}catch(PDOException $e){
		log_errors($e->getMessage());
		return 0;
	}
}


function db_insert($data = array()){
	global $conn;
	$dt = date('Y-m-d H:i:s');
	$user = current_logged_user();
	$user_id = $user['id'];
	try {
		$query = "insert into users (name,country_id,account_type,is_active,mobile,email,created_on,created_by) values (:name, :country_id, :account_type,:is_active, :mobile,:email, '$dt', $user_id)" ;
		$stmt = $conn->prepare($query);
		$stmt->execute($data);
		return $conn->lastInsertId();
	}catch(PDOException $e){
		log_errors($e->getMessage());
		return 0;
	}
}

function db_update($id, $data = array()){
	global $conn;
	$dt = date('Y-m-d H:i:s');
	$user = current_logged_user();
	$user_id = $user['id'];
	try {
		$query = "update users set name = :name, country_id = :country_id, account_type = :account_type, is_active = :is_active,
				mobile=:mobile, email=:email, updated_on = '$dt', updated_by= $user_id where id = $id" ;
		$stmt = $conn->prepare($query);
		$stmt->execute($data);
		return 1;
	}catch(PDOException $e){
		log_errors($e->getMessage());
		return 0;
	}
}

//*** QUERY ***/
function insert_query($query,$data){
	global $conn;
	try {
		$stmt = $conn->prepare($query);
		$stmt->execute($data);
		return $conn->lastInsertId();
	}catch(PDOException $e){
		log_errors($e->getMessage());
		return 0;
	}
}

function update_query($query,$data = array()){
	global $conn;
	try {
		$stmt = $conn->prepare($query);
		$stmt->execute($data);
		return 1;
	}catch(PDOException $e){
		echo $e->getMessage();
		log_errors($e->getMessage());
		return 0;
	}
}

function select_query($query,$data= array()){
	global $conn;
	$stmt = $conn->prepare($query);
	$stmt->execute($data);
	$num = $stmt->rowCount();
	if($num > 0){
		return $stmt->fetchAll();
	}else{
		return array();
	}
}

function delete_query($query){
	global $conn;
	try {
		$stmt = $conn->prepare($query);
		$stmt->execute();
		return 1;
	}catch(PDOException $e){
		log_errors($e->getMessage());
		return 0;
	}
}



//*** QUERY ***/


function generateNumericOTP($n) {
      
    // Take a generator string which consist of
    // all numeric digits
    $generator = "1357902468";
  
    // Iterate for n-times and pick a single character
    // from generator and append it to $result
      
    // Login for generating a random character from generator
    //     ---generate a random number
    //     ---take modulus of same with length of generator (say i)
    //     ---append the character at place (i) from generator to result
  
    $result = "";
  
    for ($i = 1; $i <= $n; $i++) {
        $result .= substr($generator, (rand()%(strlen($generator))), 1);
    }
  
    // Return result
    return $result;
}

function set_user_session($user_id){
	$user = get_user($user_id);
	$_SESSION['user'] = $user;
}

function is_loggedin(){
	if(!empty($_SESSION['user']['id'])){
		return true;
	}else{
		return false;
	}
}


function log_errors($msg){
	$log_file = dirname(dirname(__FILE__))  . '/logs/' . date('Y-m-d') . '.log'; 
	ini_set("log_errors", TRUE); 
	ini_set('error_log', $log_file);
	error_log($msg);
}


function log_activity($data){
	$data['created_on'] = date('Y-m-d H:i:s');
	if(empty($data['country_id']))
	$data['country_id'] = $_SESSION['user']['country_id'];
	if(empty($data['created_by']))
	$data['created_by'] = $_SESSION['user']['id'];
	if(!isset($data['meta_data'])){
		$data['meta_data'] = '';
	}

	$query = "INSERT INTO activity_logs (action_type, created_by, country_id, description, meta_data, created_on ) values
			(:action_type, :created_by, :country_id, :description,:meta_data, :created_on ) ";
	insert_query($query,$data);
}



/**
 * Starts everything and displays the template.
 */
function init()
{
	if(!is_loggedin()){
		if(isset($_COOKIE['logged_user_id']) && !empty($_COOKIE['logged_user_id'])){
			set_user_session($_COOKIE['logged_user_id']);
			require config('template_path') . '/template.php';
		}else{
			require config('template_path') . '/login.php';
		}
	}else{
		if(isset($_GET['page']) && $_GET['page']  == 'login'){
			//require config('template_path') . '/login.php';
			header('Location: ?page=home');
		}else{
			require config('template_path') . '/template.php';
		}
	}
}