<!doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.1
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login | Bootstrap Simple Admin Template</title>
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/vendor/datatables/datatables.min.css" rel="stylesheet">
    <link href="<?php site_url(); ?>/template/assets/css/master.css" rel="stylesheet">
	<link href="<?php site_url(); ?>/template/assets/css/jquery.datetimepicker.css" rel="stylesheet">

</head>
<body>
	<script>var SITE_URL = '<?php echo site_url(); ?>/';</script>
	<div class="wrapper ">
		<div class = "container">
			<div class=" text-center logo-background">
				<a href = "<?php echo site_url(). '?page=frontend-dashboard'; ?>"><img class="brand" src="<?php site_url(); ?>/template/assets/img/bootstraper-logo.png" alt="bootstraper logo"></a>
			</div>
			<div class="box box-primary">
				<div class="box-body">
				<div class = "frontend-title card-body"><?php echo config('frontend-name'); ?></div>
				<?php page_content(); ?>
				</div>
			</div>
		</div>
	</div>
    <script src="<?php site_url(); ?>/template/assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php site_url(); ?>/template/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
	<script src="<?php site_url(); ?>/template/assets/vendor/datatables/datatables.min.js"></script>

	<script src="<?php site_url(); ?>/template/assets/js/jquery.datetimepicker.full.min.js"></script>


	<script src="<?php site_url(); ?>/template/assets/js/custom_cookie.js"></script>
	<script src="<?php site_url(); ?>/template/assets/js/script-frontend.js"></script>
</body>
</html>