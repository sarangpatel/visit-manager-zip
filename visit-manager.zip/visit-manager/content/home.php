            <div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Users
                            <a href="#" class="btn  btn-primary float-end " data-bs-toggle="modal" data-bs-target="#userAddModal"><i class="fas fa-user-shield"></i> Add User</a>
                        </h3>
                    </div>
                    <div class="box box-primary">
                        <div class="box-body">
                            <table width="100%" class="table table-bordered table-hover" id="userTable">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Country</th>
                                        <th>Status</th>
                                        <th>Created on</th>
                                        <th></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

		   <div class="modal fade" id="userAddModal" role="dialog" tabindex="-1">
			  <div class="modal-dialog">
				<div class="modal-content">
				<form accept-charset="utf-8" name = "adduser_frm" id  = "adduser_frm">
					  <input type ="hidden" name = "user_id" value = "0">
					  <div class="modal-header">
						<h5 class="modal-title">Add / Edit User</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					  </div>
					  <div class="modal-body text-start">
							<div class="mb-3">
								<label class="form-label">Full Name<span class= "mandatory">*</span></label>
								<input type="text" name="name" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Email<span class= "mandatory">*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Mobile<span class= "mandatory">*</span></label>
								<input type="text" name="mobile" class="form-control">
								<small class="form-text text-muted">For Ex:  +658454049404</small>
							</div>
							<div class="mb-3">
								<label class="form-label">Country<span class= "mandatory">*</span></label>
								<select name = "country_id" class="form-control">
									<option value = "">Please Select</option>
									<?php $countries  = get_countries(); ?>
									<?php foreach($countries as $country){ ?>
										<option value = "<?php echo $country['id']; ?>"><?php echo $country['country_name']; ?></option>
									<?php } ?>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Account Type<span class= "mandatory">*</span></label>
								<select name = "account_type" class="form-control">
									<option value = "" >Please Select</option>
									<?php $acc_types = config('account_types');
									foreach ($acc_types as $k => $v) { ?>
										<option value = "<?php echo $k; ?>"><?php echo $v; ?></option>
									<?php } ?>
								</select>
							</div>
							<div class="mb-3 " >
								<label class="form-label">Status<span class= "mandatory">*</span></label>
								<select name = "is_active" class="form-control">
									<option value = "1" selected>Active</option>
									<option value = "0" >In-Active</option>
								</select>
							</div>

					  </div>
					  <div class="modal-footer">
						<button type="submit" class="btn btn-primary" >Submit</button>
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					  </div>
				</form>
				</div>
			  </div>
			</div>
